import time
import cv2
import easyocr
import pandas as pd
import re
import os
import concurrent.futures
import shutil
import warnings
import numpy as np

warnings.filterwarnings("ignore")


def preprocess_image(image):
    im_gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    clahe = cv2.createCLAHE(clipLimit=3.0, tileGridSize=(8, 8))
    im_clahe = clahe.apply(im_gray)
    im_denoised = cv2.fastNlMeansDenoising(im_clahe, h=10)
    im_thresh = cv2.adaptiveThreshold(
        im_denoised, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 21, 5
    )
    return im_thresh


def read_image(file, config, skipped):
    try:
        im = cv2.imread(file)
        if im is None:
            raise ValueError(f"Cannot read image: {file}")

        im_thresh = preprocess_image(im)
        preprocessed_path = f"preprocessed_{os.path.basename(file)}"
        cv2.imwrite(preprocessed_path, im_thresh)

        reader = easyocr.Reader(['en'], gpu=False)
        results = reader.readtext(im_thresh, paragraph=False, detail=0)

        # حذف خطوط مربوط به سرستون‌ها و فقط نگه داشتن مقادیر عددی
        header_keywords = ['Vin', 'Vout', 'V out', 'Iul', 'Ivl', 'Iwl', 'U-N', 'V-N', 'W-N', 'mA', 'VN']
        data_rows = []
        for text in results:
            text = text.strip()
            if not text:
                continue
            # اگر متن شامل کلمات سرستون بود، ردش کن
            if any(keyword in text for keyword in header_keywords):
                continue
            # فقط مقادیر عددی رو نگه دار (مثلاً 219.2, 1.5, و غیره)
            if re.match(r'^\d+(\.\d+)?$', text):
                data_rows.append(text)

        if len(data_rows) < 9:
            raise ValueError("Not enough data to form a table")

        # سرستون‌ها (برگردوندن به ترتیب اصلی)
        header = ["Vin U-N", "V out B U-N", "Iu1 [mA]", "Vin V-N", "V out B V-N", "Iv1 [mA]", "Vin W-N", "V out B W-N",
                  "Iw1 [mA]"]
        expected_cols = len(header)
        header.append("file")

        df = pd.DataFrame(columns=header)
        for i in range(0, len(data_rows), expected_cols):
            row_values = data_rows[i:i + expected_cols]
            if len(row_values) == expected_cols:
                row_values.append(file)
                df.loc[len(df)] = row_values
            else:
                skipped_row = pd.DataFrame({"skipped": [" ".join(row_values)], "file": [file]})
                skipped = pd.concat([skipped, skipped_row], ignore_index=True)

        return df, skipped

    except Exception as e:
        print(f"Error processing {file}: {e}")
        skipped_row = pd.DataFrame({"skipped": [f"Error: {str(e)}"], "file": [file]})
        return pd.DataFrame(), pd.concat([skipped, skipped_row], ignore_index=True)


def read_images_in_folder(folder, config):
    if not os.path.exists(folder):
        raise FileNotFoundError(f"Folder '{folder}' does not exist.")

    skipped = pd.DataFrame(columns=["skipped"])
    df = pd.DataFrame()

    valid_extensions = [".png", ".jpg", ".jpeg", ".bmp", ".tiff"]
    files = [
        os.path.join(folder, file)
        for file in os.listdir(folder)
        if any(file.endswith(ext) for ext in valid_extensions)
    ]

    if not files:
        raise ValueError(f"No valid images found in '{folder}'. Supported formats: {valid_extensions}")

    processed_files_folder = os.path.join(config["processed_files_folder"])
    if not os.path.exists(processed_files_folder):
        os.makedirs(processed_files_folder)

    with concurrent.futures.ProcessPoolExecutor() as executor:
        results = executor.map(
            read_image, files, [config] * len(files), [skipped] * len(files)
        )

    for file, result in zip(files, results):
        dataframe, new_skipped = result
        df = pd.concat([df, dataframe], ignore_index=True)
        skipped_row = pd.DataFrame(new_skipped, columns=["skipped"])
        skipped = pd.concat([skipped, skipped_row], ignore_index=True)
        destination = os.path.join(processed_files_folder, os.path.basename(file))
        shutil.move(file, destination)
    return df, skipped


def read_onefile(file, config):
    if not os.path.exists(file):
        raise FileNotFoundError(f"File '{file}' does not exist.")
    skipped = pd.DataFrame(columns=["skipped"])
    df, skipped = read_image(file, config, skipped)
    return df, skipped


if __name__ == "__main__":
    config = {
        "dilation": (7, 7),
        "blur": 21,
        "preprocessed_image_path": "preprocessed.png",
        "tesseract": r"",
        "processed_files_folder": "processed_files",
    }

    print("لطفاً مسیر فایل تصویر یا پوشه تصاویر را وارد کنید (مثال: E:\\Images یا E:\\Images\\sample.jpg):")
    user_input = input().strip()

    outfile = r"C:\Users\ADMIN\Desktop\output.xlsx"

    if os.path.isfile(user_input) and any(
            user_input.lower().endswith(ext) for ext in [".png", ".jpg", ".jpeg", ".bmp", ".tiff"]):
        df, skipped = read_onefile(user_input, config)
    elif os.path.isdir(user_input):
        df, skipped = read_images_in_folder(user_input, config)
    else:
        print(f"ورودی نامعتبر است. لطفاً یک فایل تصویر یا پوشه معتبر وارد کنید.")
        exit(1)

    try:
        with pd.ExcelWriter(outfile) as writer:
            df.to_excel(writer, sheet_name="data", index=False)
            skipped.to_excel(writer, sheet_name="skipped", index=False)
        print(f"فایل اکسل با موفقیت در {os.path.abspath(outfile)} ذخیره شد.")
    except PermissionError as e:
        print(f"خطا در ذخیره فایل: {e}. لطفاً مطمئن شوید که فایل '{outfile}' باز نیست و دسترسی نوشتن دارید.")
        exit(1)