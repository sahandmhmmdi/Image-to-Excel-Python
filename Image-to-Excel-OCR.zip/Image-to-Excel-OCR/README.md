# 🧠 Image to Excel – OCR Table Extractor

This Python project allows you to extract numerical data from industrial measurement images using **EasyOCR**, clean and structure the data, and export it to an Excel file.

📸 Input: Scanned or captured images of measurement data  
📊 Output: Cleaned table in `.xlsx` format (plus skipped entries)  
🧰 Built with: Python, OpenCV, EasyOCR, Pandas

---

## 🚀 Features

- Preprocessing with CLAHE, denoising, and adaptive thresholding
- Intelligent filtering to remove headers and noise
- Supports both single files and folders
- Parallel processing with `ProcessPoolExecutor`
- Automatically saves skipped/error rows

---

## 📁 Folder Structure

```bash
📂 sample_input/         → Sample images for testing
📂 processed_files/      → Automatically moved images after processing
📂 sample_output/        → Output Excel files
📄 main.py               → Main OCR + export logic
📄 requirements.txt      → Install dependencies
```

---

## 🔧 Installation

```bash
git clone https://github.com/YOUR_USERNAME/Image-to-Excel-OCR.git
cd Image-to-Excel-OCR
pip install -r requirements.txt
```

---

## 🛠️ Usage

```bash
python main.py
```

Then enter:
- A single image path (e.g. `E:\Images\img1.jpg`)
- Or a folder path (e.g. `E:\Images`)

Excel file will be saved to:  
`C:\Users\ADMIN\Desktop\output.xlsx`

---

## 📎 Sample Output

| Vin U-N | V out B U-N | Iu1 [mA] | ... |
|---------|--------------|----------|-----|
| 219.1   | 215.3        | 1.45     | ... |

---

## ✨ Author

Created by **Sahand Mohammadi**  
Electrical Engineering Student | University of Kurdistan  
IEEE Student Member | Control & Power Systems

---

## 📄 License

MIT (or your choice)
